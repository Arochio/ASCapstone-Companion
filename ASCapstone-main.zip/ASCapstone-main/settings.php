<?php include("includes/head.php");
// session_start();?>
<body>
    <header class="flex" style="align-items:flex-start;">

        <!--***Make this change based on selected client***-->
        <div class="flex" id="leftHead">
            <p>Settings</p>
        </div>

        <div class="dropdown">
            <!-- ***Make this change based on logged in user -->
            <button class="dropbtn"><?=$_SESSION["displayName"]?></button>
            <div class="userMenu">

                <a href="settings.php">
                    <?php
                    if($_SESSION["isAdmin"]):?>
                        Admin/Settings
                    <?php else: ?>
                        User Settings
                    <?php endif;?>
                </a>

                <!-- Dark Mode toggle Put on Ice for now :( -->
                <!-- <div class="flex">
                    Dark Mode
                    <label class="toggle">
                        <input type="checkbox" id="isDarkMode">
                        <span class="slider"></span>
                    </label>
                </div> -->
                <a href="index.php">Log Out</a>
            </div>
        </div>
    </header>
    <main id="settings">
        <?php if($_SESSION["isAdmin"]){include("includes/fiduciary.php");}?>

        <!-- This empty div makes sure that the user settings panel stays put when user isn't an admin -->
        <div></div>
        <?php include("includes/userSettings.php");?>
    </main>
</body>
<script src="functions/fiduciary.js"></script>
