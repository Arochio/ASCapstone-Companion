<!-- use individual header for login page -->
<?php

include("functions/functions.php");
session_start();


$logError = TRUE;

//log out if logged in when loading index page
if(isset($_SESSION["isLoggedIn"])) {
    echo('<script>alert("index.php");</script>');
    logout();
}

if(isset($_POST['username']) && isset($_POST['password'])) {
    $username = filter_input(INPUT_POST,'username', FILTER_SANITIZE_STRING);
    $password = filter_input(INPUT_POST,'password', FILTER_SANITIZE_STRING);
    $logError = login($username, $password);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Change Document Title Per Page -->
    <title>Login</title>
    <link rel="stylesheet" href="styles/main.css">

    <script src="https://kit.fontawesome.com/61a36f0003.js" crossorigin="anonymous"></script>
</head>
<body id="loginBody">
    <div id="loginMain">
        <div class="loginLogo" style="color:white;">
            <!-- <h1>Maybe a fancy logo here some day?</h1> -->
        </div>
        <div>
            <form method="POST" id="login">
                <div>
                    <label for="username">Username:</label>
                    <input type="text" id="username" name="username" autocomplete="off">            
                </div>
                <div>
                    <label for="password">Password:</label>
                    <input type="password" id="password" name="password" autocomplete="off">            
                </div>
                <div class="loginButt">
                    <button type="submit" class="transButt">Log In</button>            
                </div>

            </form>   
            <?php
                if(!$logError):?>
                    <div class="error" style='color: red;'>Username or password is invalid.<br>Please try again.</div><br>
            <?php endif;?>
        
        </div>

        <div class="loginHelp">
            <p class="shyTxt">Having trouble logging in? Contact IT at: ###-####</p>
        </div>        
    </div>
    <footer>
        <a href="https://arochio.github.io/ASCapstone-Companion/" style="color:white;">Companion Site</a>
    </footer>
</body>
</html>