<?php
include("functions/functions.php");
session_start();

if(isset($_SESSION['clientID'])) {$clientID = $_SESSION['clientID'];}
if(isset($clientID)) {
    $clientData = getOneClient($clientID)[0];
    $clientName = '';
    if($clientData['clientFName'] != '') {$clientName .= $clientData['clientFName'];}
    if($clientData['clientMName'] != '') {$clientName .= ' ' . $clientData['clientMName'];}
    if($clientData['clientLName'] != '') {$clientName .= ' ' . $clientData['clientLName'];}

    $groups = getGroups($clientID);

    if(isset($_POST['checkIsRange'])) {
        if(isset($_POST['printStart'])) {$dateStart = $_POST['printStart'];}
        if(isset($_POST['printEnd'])) {$dateEnd = $_POST['printEnd'];}
    }
    else {
        $dateStart = '0001/01/01';
        $dateEnd = date('Y/m/d');
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Print Schedules</title>
    <link rel="stylesheet" href="/ASCapstone/styles/schedules.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Libertinus+Mono&display=swap" rel="stylesheet">
</head>
<body>
<?php
    if(isset($_POST['checkInv'])) {
            $_SESSION['docName'] = 'Inventory';
            include('includes\schedules.php');
    }

    if(isset($_POST['checkPerLast'])) { //get last accounting values (day before startDate)
        $banks = getBanks($clientID);
        $bankTotals = [];
        if($banks !== 'No Banks Found'):
        foreach($banks as $bank){
            $bankBal = 0;
            $transactions = getTrans($clientID, $bank['bankID']);

            if($transactions != "No Transactions Found"){
                foreach($transactions as $trans){
                    if($trans['bankIn'] == $bank['bankID']) {
                        $bankBal += $trans['amount'];
                    }
                    else if($trans['bankOut'] == $bank['bankID']) {
                        $bankBal -= $trans['amount'];
                    }
                    else {
                        echo('<script>alert("not bankIn or bankOut")</script>');
                    }
                }                
            }

            $bankTotals[$bank['bankName'] . '#' . $bank['bankNum']] = $bankBal;
        }
        endif;
        $_SESSION['docName'] = 'Per Last Accounting';
        include('includes\schedules.php');
    }

    if(isset($_POST['checkIncome'])) {
        $_SESSION['docName'] = 'Income';
        include('includes\schedules.php');
    }

    if(isset($_POST['checkExpenses'])) {
        $_SESSION['docName'] = 'Expenses';
        include('includes\schedules.php');
    }

    if(isset($_POST['checkTransfers'])) {
        $_SESSION['docName'] = 'Transfers';
        include('includes\schedules.php');
    }

}
echo("<script>window.print()</script>;");
?>