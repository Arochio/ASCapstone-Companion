window.addEventListener('beforeunload', (e) => {
        var isDarkMode = sessionStorage.getItem('darkMode');
        var userFontSize = sessionStorage.getItem('fontSize');

        //create array and send to shutdown.php
        var userSettings = [isDarkMode, userFontSize];
        navigator.sendBeacon("includes/shutdown.php", userSettings);
});
