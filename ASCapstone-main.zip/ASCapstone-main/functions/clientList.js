var search = document.querySelector('#clientSearch');
const clientList = document.querySelectorAll('#clientDisplay .clientDisplay');

search.addEventListener('input', (e) => {

    clientList.forEach(clientRow => {

        // Get name
        var clientText = clientRow.querySelector('.clientName').innerText.toString();
        clientText = clientText.toLowerCase();
        console.log(clientText);

        //Get the name in FName LName format
        var clientName = clientText.split(', ');
        clientName = `${clientName[1]} ${clientName[0]}`.toString();
        clientName = clientName.toLowerCase();

        // get number
        var clientNum = clientRow.querySelector('.clientNum').innerHTML.toString();
        clientNum = clientNum.toLowerCase();
        var clientNumDash = clientNum.replace('-','');
        console.log(clientNumDash);

        if(clientText.includes(search.value.toLowerCase()) || clientNum.includes(search.value) || clientName.includes(search.value.toLowerCase()) || clientNumDash.includes(search.value)){
            console.log("found");
            clientRow.classList.remove("hidden");

        }
        else{
            clientRow.classList.add("hidden");
        }
    });
});