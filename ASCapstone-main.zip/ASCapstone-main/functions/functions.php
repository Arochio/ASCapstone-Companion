<?php
ignore_user_abort(TRUE);

include("C:/xampp/htdocs/ASCapstone/database/db.php");

function addClient($fidID, $fName, $mName, $lName, $appDate, $dob, $dod, $caseNum, $clientAddress, $city, $clientState, $zip) {
    global $db;
    $results = [];

    if($dod !=''){
        $query = $db->prepare("INSERT INTO clients SET fiduciaryID = :fidID, clientFName = :fName, clientMName = :mName, clientLName = :lName, dateAppt = :appDate, dateBirth = :dob, dateDeath = :dod, caseNum = :caseNum, clientAddress = :clientAddress, clientCity = :city, clientState = :clientState, clientZip = :zip");

        $binds = array(
            ":fidID" => $fidID,
            ":fName" => $fName,
            ":mName" => $mName,
            ":lName" => $lName,
            ":appDate" => $appDate,
            ":dob" => $dob,
            ":dod" => $dod,
            ":caseNum" => $caseNum,
            ":clientAddress" => $clientAddress,
            ":city" => $city,
            ":clientState" => $clientState,
            ":zip" => $zip
        );        
    }
    else{
        $query = $db->prepare("INSERT INTO clients SET fiduciaryID = :fidID, clientFName = :fName, clientMName = :mName, clientLName = :lName, dateAppt = :appDate, dateBirth = :dob, dateDeath = NULL, caseNum = :caseNum, clientAddress = :clientAddress, clientCity = :city, clientState = :clientState, clientZip = :zip");

        $binds = array(
            ":fidID" => $fidID,
            ":fName" => $fName,
            ":mName" => $mName,
            ":lName" => $lName,
            ":appDate" => $appDate,
            ":dob" => $dob,
            ":caseNum" => $caseNum,
            ":clientAddress" => $clientAddress,
            ":city" => $city,
            ":clientState" => $clientState,
            ":zip" => $zip
        );           
    }
    

    if($query->execute($binds) && $query->rowCount() > 0) {
        $results = "Client Added.";
    }

    return $results;
}

//user settings will be given a default value then updated using logout()
//$userFName for clarity, $userPass to avoid conflict with mySQL
//add hash for password
function addUser($username, $userPass, $displayName, $isAdmin) {
    global $db;
    $results = '';

    if(!checkUsername($username)) {
        return FALSE;
    }

    $query = $db->prepare("INSERT INTO users SET username = :username, userPass = :userPass, displayName = :displayName, isAdmin = :isAdmin;");

    $binds = array(
        ":username" => $username,
        ":userPass" => $userPass,
        ":displayName" => $displayName,
        ":isAdmin" => $isAdmin
    );

    if($query->execute($binds) && $query->rowCount() > 0) {
        return TRUE;
    }

    
}

function checkUsername($username) {
    global $db;

    $query = $db->prepare("SELECT * FROM users WHERE username = :username;");

    $binds = array(
        ":username" => $username
    );

    if($query->execute($binds) && $query->rowCount() > 0) {
        return FALSE;
    }

    return TRUE;
}

function addTrans($transName, $amount, $transDate, $transType, $transGroup, $bankIn, $bankOut, $checkNum, $memo, $clientID) {
    global $db;
    $results = [];

    

    if(!$bankIn) {
        $query = $db->prepare("INSERT INTO transactions SET clientID = :clientID, transType = :transType, transName = :transName, memo = :memo, transDate = :transDate, amount = :amount, bankOut = :bankOut, checkNum = :checkNum, transGroup = :transGroup");
        $binds = array(
            ":clientID" => $clientID,
            ":transType" => $transType,
            ":transName" => $transName,
            ":memo" => $memo,
            ":transDate" => $transDate,
            ":amount" => $amount,
            ":bankOut" => $bankOut,
            ":checkNum" => $checkNum,
            ":transGroup" => $transGroup
        );
    }
    else if(!$bankOut) {
        $query = $db->prepare("INSERT INTO transactions SET clientID = :clientID, transType = :transType, transName = :transName, memo = :memo, transDate = :transDate, amount = :amount, bankIn = :bankIn, checkNum = :checkNum, transGroup = :transGroup");
        $binds = array(
            ":clientID" => $clientID,
            ":transType" => $transType,
            ":transName" => $transName,
            ":memo" => $memo,
            ":transDate" => $transDate,
            ":amount" => $amount,
            ":bankIn" => $bankIn,
            ":checkNum" => $checkNum,
            ":transGroup" => $transGroup
        );
    }
    else {
        $query = $db->prepare("INSERT INTO transactions SET clientID = :clientID, transType = :transType, transName = :transName, memo = :memo, transDate = :transDate, amount = :amount, bankIn = :bankIn, bankOut = :bankOut, checkNum = :checkNum, transGroup = :transGroup");
        $binds = array(
            ":clientID" => $clientID,
            ":transType" => $transType,
            ":transName" => $transName,
            ":memo" => $memo,
            ":transDate" => $transDate,
            ":amount" => $amount,
            ":bankIn" => $bankIn,
            ":bankOut" => $bankOut,
            ":checkNum" => $checkNum,
            ":transGroup" => $transGroup
        );
    }

    

    if($query->execute($binds) && $query->rowCount() > 0) {
        $results = "Transaction Added.";
    }
    else {
        return "Failed to add transaction.";
    }

    return $results;
}

//should add to admin-only app eventually
//"fid" prefix for clarity
function addFiduciary($fidFName, $fidMName, $fidLName, $fidAddress, $fidCity, $fidState, $fidZip, $fidTitle, $fidPhone) {
    global $db;
    $results = [];

    $query = $db->prepare("INSERT INTO fiduciaries SET fidFName = :fidFName, fidMName = :fidMName, fidLName = :fidLName, fidAddress = :fidAddress, fidCity = :fidCity, fidState = :fidState, fidZip = :fidZip, fidTitle = :fidTitle, fidPhone = :fidPhone;");

    $binds = array(
        ":fidFName" => $fidFName,
        ":fidMName" => $fidMName,
        ":fidLName" => $fidLName,
        ":fidAddress" => $fidAddress,
        ":fidCity" => $fidCity,
        ":fidState" => $fidState,
        ":fidZip" => $fidZip,
        ":fidTitle" => $fidTitle,
        ":fidPhone" => $fidPhone

    );

    if($query->execute($binds) && $query->rowCount() > 0) {
        $results = "Fiduciary Added.";
    }

    return $results;
}

//bankNum will have to be calculated based on length of banks matching the clientID (should work for now)
function addBank($clientID, $bankName, $bankNum) {
    global $db;
    $results = [];

    $clientBankID = getClientBankID($clientID) + 1;

    $query = $db->prepare("INSERT INTO banks SET clientID = :clientID, bankName = :bankName, bankNum = :bankNum, clientBankID = :clientBankID;");

    $binds = array(
        ":clientID" => $clientID,
        ":bankName" => $bankName,
        ":bankNum" => $bankNum,
        ":clientBankID" => $clientBankID
    );

    if($query->execute($binds) && $query->rowCount() > 0) {
        $results = "Bank Added.";
    }

    return $results;
}

//used by addBank to determine bankNum for banks table
function getClientBankID($clientID) {
    global $db;
    $results = [];

    $query = $db->prepare("SELECT * FROM banks WHERE clientID = :clientID;");

    $binds = array(
        ":clientID" => $clientID
    );

    if($query->execute($binds) && $query->rowCount() > 0) {
        $results = $query->rowCount();
    }
    else {
        $results = 0;
    }

    return $results;
}

function getClients() {
    global $db;
    $results = [];

    $query = $db->prepare("SELECT * FROM clients;");

    if($query->execute() && $query->rowCount() > 0) {
        $results = $query->fetchAll(PDO::FETCH_ASSOC);
    }
    else {
        $results = "No Clients Found";
    }

    return $results;
}
function getActiveClients() {
    global $db;
    $results = [];

    $query = $db->prepare("SELECT * FROM clients WHERE isActive = 1 ORDER BY clientLName ASC;");

    if($query->execute() && $query->rowCount() > 0) {
        $results = $query->fetchAll(PDO::FETCH_ASSOC);
    }
    else {
        $results = "No Clients Found";
    }

    return $results;
}
function getInactiveClients() {
    global $db;
    $results = [];

    $query = $db->prepare("SELECT * FROM clients WHERE isActive = 0 ORDER BY clientLName ASC;");

    if($query->execute() && $query->rowCount() > 0) {
        $results = $query->fetchAll(PDO::FETCH_ASSOC);
    }
    else {
        $results = "No Clients Found";
    }

    return $results;
}
function getOneClient($clientID){
    global $db;
    $results = [];

    $query = $db->prepare("SELECT * FROM clients WHERE clientID = :clientID;");

    $binds = array(
        ":clientID" => $clientID
    );

    if($query->execute($binds) && $query->rowCount() > 0){
        $results = $query->fetchAll(PDO::FETCH_ASSOC);
    }
    else{
        $results = "No Client Found";
    }

    return $results;
}
function getGroups($clientID) {
    global $db;
    $results = [];

    $query = $db->prepare("SELECT DISTINCT t.transGroup FROM transactions t JOIN banks b ON t.clientID = b.clientID WHERE b.clientID = :clientID;");

    $binds = array(
        ":clientID" => $clientID
    );

    if($query->execute($binds) && $query->rowCount() > 0) {
        $results = $query->fetchAll(PDO::FETCH_ASSOC);
    }
    else {
        $results = "No Groups Found";
    }

    return $results;
}

function getBanks($clientID) {
    global $db;
    $results = [];

    $query = $db->prepare("SELECT * FROM banks WHERE clientID = :clientID;");

    $binds = array(
        ":clientID" => $clientID
    );

    if($query->execute($binds) && $query->rowCount() > 0) {
        $results = $query->fetchAll(PDO::FETCH_ASSOC);
    }
    else {
        $results = "No Banks Found";
    }

    return $results;
}

function getBankFromName($bankName, $bankNum, $clientID) {
    global $db;
    $results = [];

    $query = $db->prepare("SELECT * FROM banks WHERE bankName = :bankName AND bankNum = :bankNum AND clientID = :clientID;");

    $binds = array(
        ":bankName" => $bankName,
        ":bankNum" => $bankNum,
        ":clientID" => $clientID
    );

    if($query->execute($binds) && $query->rowCount() > 0) {
        $results = $query->fetch();
    }
    else {
        return -1;
    }

    return $results["bankID"];
}

function getBankFromID($bankID) {
    global $db;
    $results = [];

    $query = $db->prepare("SELECT * FROM banks where bankID = :bankID;");

    $binds = array(
        ":bankID" => $bankID
    );

    if($query->execute($binds) && $query->rowCount() > 0) {
        $results = $query->fetch();
    }
    else {
        return -1;
    }

    return $results;
}

function getTrans($clientID, $bankID) {
    global $db;
    $results = [];

    if($bankID == FALSE){
        $query = $db->prepare("SELECT * FROM transactions WHERE clientID = :clientID ORDER BY transDate ASC;");
        $binds = array(":clientID" => $clientID);
    }
    else {
        $query = $db->prepare("SELECT * FROM transactions WHERE clientID = :clientID AND (bankIn = :bankIn OR bankOut = :bankOut) ORDER BY transDate ASC;");
        $binds = array(
        ":clientID" => $clientID,
        ":bankIn" => $bankID,
        ":bankOut" => $bankID
        );
    }

    if($query->execute($binds) && $query->rowCount() > 0) {
        $results = $query->fetchAll(PDO::FETCH_ASSOC);
    }
    else {
        $results = "No Transactions Found";
    }

    return $results;
}
function getOneTrans($transID) {
    global $db;
    $results = [];

    $query = $db->prepare("SELECT * FROM transactions where transID = :transID;");

    $binds = array(
        ":transID" => $transID
    );

    if($query->execute($binds) && $query->rowCount() > 0) {
        $results = $query->fetch();
    }
    else {
        return -1;
    }

    return $results;
}
function getUsers() {
    global $db;
    $results = [];

    $query = $db->prepare("SELECT * FROM users;");

    if($query->execute() && $query->rowCount() > 0) {
        $results = $query->fetchAll(PDO::FETCH_ASSOC);
    }
    else {
        $results = "No Users Found";
    }

    return $results;
}

function getFiduciary() {
    global $db;
    $results = [];

    $query = $db->prepare("SELECT * FROM fiduciaries;");

    if($query->execute() && $query->rowCount() > 0) {
        $results = $query->fetchAll(PDO::FETCH_ASSOC);
    }
    else {
        $results = "No Fiduciaries Found";
    }

    return $results;
}

function delClient($clientID) {
    global $db;
    $results = [];

    $query = $db->prepare("DELETE FROM clients WHERE clientID = :clientID;");

    $binds = array(
        ":clientID" => $clientID
    );

    if($query->execute($binds) && $query->rowCount() > 0) {
        $results = "Client deleted";
    }

    return $results;
}
function activateClient($isActive, $clientID){
    global $db;
    $results = [];

    $query = $db->prepare("UPDATE clients SET isActive = :isActive WHERE clientID = :clientID;");

    $binds = array(
        ":isActive" => $isActive,
        ":clientID" => $clientID
    );
    if($query->execute($binds) && $query->rowCount() > 0) {
        $results = "Client Deactivated";
    }
    return $results;
}
function delTrans($transID) {
    global $db;
    $results = [];

    $query = $db->prepare("DELETE FROM transactions WHERE transID = :transID;");

    $binds = array(
        ":transID" => $transID
    );

    if($query->execute($binds) && $query->rowCount() > 0) {
        $results = "Transaction deleted";
    }

    return $results;
}

function delFiduciary($fiduciaryID) {
    global $db;
    $results = [];

    $query = $db->prepare("DELETE FROM fiduciaries WHERE fiduciaryID = :fiduciaryID;");

    $binds = array(
        ":fiduciaryID" => $fiduciaryID
    );

    if($query->execute($binds) && $query->rowCount() > 0) {
        $results = "Fiduciary deleted";
    }

    return $results;
}

function delUser($userID) {
    global $db;
    $results = '';

    $query = $db->prepare("DELETE FROM users WHERE userID = :userID;");

    $binds = array(
        ":userID" => $userID
    );

    if($query->execute($binds) && $query->rowCount() > 0) {
        $results = "User deleted";
    }

    return $results;
}

function editClient($fidID, $fName, $mName, $lName, $appDate, $dob, $dod, $caseNum, $clientAddress, $city, $clientState, $zip, $clientID) {
    global $db;
    $results = [];

    if($mName == "" && $dod == ""){
        $query = $db->prepare("UPDATE clients SET fiduciaryID = :fidID, clientFName = :fName, clientMName = NULL, clientLName = :lName, dateAppt = :appDate, dateBirth = :dob, dateDeath = NULL, caseNum = :caseNum, clientAddress = :clientAddress, clientCity = :city, clientState = :clientState, clientZip = :zip WHERE clientID = :clientID;");

        $binds = array(
            ":fidID" => $fidID,
            ":fName" => $fName,
            ":lName" => $lName,
            ":appDate" => $appDate,
            ":dob" => $dob,
            ":caseNum" => $caseNum,
            ":clientAddress" => $clientAddress,
            ":city" => $city,
            ":clientState" => $clientState,
            ":zip" => $zip,
            ":clientID" => $clientID
        );        
    }
    else if($dod == ""){
        $query = $db->prepare("UPDATE clients SET fiduciaryID = :fidID, clientFName = :fName, clientMName = :mName, clientLName = :lName, dateAppt = :appDate, dateBirth = :dob, dateDeath = NULL, caseNum = :caseNum, clientAddress = :clientAddress, clientCity = :city, clientState = :clientState, clientZip = :zip WHERE clientID = :clientID;");

        $binds = array(
            ":fidID" => $fidID,
            ":fName" => $fName,
            ":mName" => $mName,
            ":lName" => $lName,
            ":appDate" => $appDate,
            ":dob" => $dob,
            ":caseNum" => $caseNum,
            ":clientAddress" => $clientAddress,
            ":city" => $city,
            ":clientState" => $clientState,
            ":zip" => $zip,
            ":clientID" => $clientID
        );    
    }
    else if($mName ==""){
        $query = $db->prepare("UPDATE clients SET fiduciaryID = :fidID, clientFName = :fName, clientMName = NULL, clientLName = :lName, dateAppt = :appDate, dateBirth = :dob, dateDeath = :dod, caseNum = :caseNum, clientAddress = :clientAddress, clientCity = :city, clientState = :clientState, clientZip = :zip WHERE clientID = :clientID;");

        $binds = array(
            ":fidID" => $fidID,
            ":fName" => $fName,
            ":lName" => $lName,
            ":appDate" => $appDate,
            ":dob" => $dob,
            ":dod" => $dod,
            ":caseNum" => $caseNum,
            ":clientAddress" => $clientAddress,
            ":city" => $city,
            ":clientState" => $clientState,
            ":zip" => $zip,
            ":clientID" => $clientID
        );
    }
    else{
        $query = $db->prepare("UPDATE clients SET fiduciaryID = :fidID, clientFName = :fName, clientMName = :mName, clientLName = :lName, dateAppt = :appDate, dateBirth = :dob, dateDeath = :dod, caseNum = :caseNum, clientAddress = :clientAddress, clientCity = :city, clientState = :clientState, clientZip = :zip WHERE clientID = :clientID;");

        $binds = array(
            ":fidID" => $fidID,
            ":fName" => $fName,
            ":mName" => $mName,
            ":lName" => $lName,
            ":appDate" => $appDate,
            ":dob" => $dob,
            ":dod" => $dod,
            ":caseNum" => $caseNum,
            ":clientAddress" => $clientAddress,
            ":city" => $city,
            ":clientState" => $clientState,
            ":zip" => $zip,
            ":clientID" => $clientID
        );
    }
    

    if($query->execute($binds) && $query->rowCount() > 0) {
        $results = "Client updated.";
    }

    return $results;
}

function editUser($username, $userPass, $displayName, $isAdmin, $userID) {
    global $db;
    $results = [];

    $query = $db->prepare("UPDATE users SET username = :username, userPass = :userPass, displayName = :displayName, isAdmin = :isAdmin WHERE userID = :userID;");

    $binds = array(
        ":username" => $username,
        ":userPass" => $userPass,
        ":displayName" => $displayName,
        ":userID" => $userID,
        ":isAdmin" => $isAdmin
    );


    if($query->execute($binds) && $query->rowCount() > 0) {
        return TRUE;
    }

    return FALSE;
}
function updateUserSettings() {
    ignore_user_abort(TRUE);
    global $db;
    $results = [];

    $query = $db->prepare("UPDATE users SET settings = :settings WHERE userID = :userID;");

    $binds = array(
        ":settings" => json_encode($_SESSION["userSettings"]),
        ":userID" => $_SESSION["userID"]
    );


    if($query->execute($binds) && $query->rowCount() > 0) {
        return TRUE;
    }

    return FALSE;
}

function editTrans($clientID, $transType, $transName, $memo, $transDate, $amount, $bankIn, $bankOut, $checkNum, $group, $transID) {
    global $db;
    $results = [];


    if(!$bankIn){
        $query = $db->prepare("UPDATE transactions SET clientID = :clientID, transType = :transType, transName = :transName, memo = :memo, transDate = :transDate, amount = :amount, bankIn = NULL, bankOut = :bankOut, checkNum = :checkNum, transGroup = :group WHERE transID = :transID;");

        $binds = array(
            ":clientID" => $clientID,
            ":transType" => $transType,
            ":transName" => $transName,
            ":memo" => $memo,
            ":transDate" => $transDate,
            ":amount" => $amount,
            ":bankOut" => $bankOut,
            ":checkNum" => $checkNum,
            ":group" => $group,
            ":transID" => $transID
        );
    }
    else if(!$bankOut){
        $query = $db->prepare("UPDATE transactions SET clientID = :clientID, transType = :transType, transName = :transName, memo = :memo, transDate = :transDate, amount = :amount, bankIn = :bankIn, bankOut = NULL, checkNum = :checkNum, transGroup = :group WHERE transID = :transID;");

        $binds = array(
            ":clientID" => $clientID,
            ":transType" => $transType,
            ":transName" => $transName,
            ":memo" => $memo,
            ":transDate" => $transDate,
            ":amount" => $amount,
            ":bankIn" => $bankIn,
            ":checkNum" => $checkNum,
            ":group" => $group,
            ":transID" => $transID
        );
    }
    else{
        $query = $db->prepare("UPDATE transactions SET clientID = :clientID, transType = :transType, transName = :transName, memo = :memo, transDate = :transDate, amount = :amount, bankIn = :bankIn, bankOut = :bankOut, checkNum = :checkNum, transGroup = :group WHERE transID = :transID;");

        $binds = array(
            ":clientID" => $clientID,
            ":transType" => $transType,
            ":transName" => $transName,
            ":memo" => $memo,
            ":transDate" => $transDate,
            ":amount" => $amount,
            ":bankIn" => $bankIn,
            ":bankOut" => $bankOut,
            ":checkNum" => $checkNum,
            ":group" => $group,
            ":transID" => $transID
        );
    }

    if($query->execute($binds) && $query->rowCount() > 0) {
        $results = "Transaction updated.";
    }

    return $results;
}

function editFiduciary($fidFName, $fidMName, $fidLName, $fidAddress, $fidCity, $fidState, $fidZip, $fidTitle, $fidPhone, $fiduciaryID) {
    global $db;
    $results = [];

    $query = $db->prepare("UPDATE fiduciaries SET fidFName = :fidFName, fidMName = :fidMName, fidLName = :fidLName, fidAddress = :fidAddress, fidCity = :fidCity, fidState = :fidState, fidZip = :fidZip, fidTitle = :fidTitle, fidPhone = :fidPhone WHERE fiduciaryID = :fiduciaryID;");

    $binds = array(
        ":fidFName" => $fidFName,
        ":fidMName" => $fidMName,
        ":fidLName" => $fidLName,
        ":fidAddress" => $fidAddress,
        ":fidCity" => $fidCity,
        ":fidState" => $fidState,
        ":fidZip" => $fidZip,
        ":fidTitle" => $fidTitle,
        ":fidPhone" => $fidPhone,
        ":fiduciaryID" => $fiduciaryID

    );

    if($query->execute($binds) && $query->rowCount() > 0) {
        $results = "Fiduciary updated.";
    }

    return $results;
}

function editBank($clientID, $bankName, $bankNum, $bankID) {
    global $db;
    $results = [];

    $query = $db->prepare("INSERT INTO banks SET clientID = :clientID, bankName = :bankName, bankNum = :bankNum WHERE bankID = :bankID;");

    $binds = array(
        ":clientID" => $clientID,
        ":bankName" => $bankName,
        ":bankNum" => $bankNum,
        ":bankID" => $bankID
    );

    if($query->execute($binds) && $query->rowCount() > 0) {
        $results = "Bank updated.";
    }

    return $results;
}

function logout() {
    ignore_user_abort(TRUE);
    session_start();
    updateUserSettings();
    session_unset();
    session_destroy();

    header('Location: /ASCapstone/index.php');
    exit();
}

function login($username, $password) {

    global $db;

    $query = $db->prepare("SELECT * FROM users WHERE username = :u and userPass = :p");

    $binds = array(
        ":u" => $username,
        ":p" => $password
    );

    if($query->execute($binds) && $query->rowCount() > 0) {
        session_start();
        unset($_POST);
        $_SESSION["isLoggedIn"] = TRUE;
        $userInfo = $query->fetch(); //gets one record
        $_SESSION["displayName"] = $userInfo["displayName"];
        $_SESSION["userID"] = $userInfo["userID"];
        $_SESSION["isAdmin"] = $userInfo["isAdmin"];
        $settingsJSON = $userInfo["settings"];

        //untested nonsense
        if($settingsJSON != null){
            $_SESSION["userSettings"] = json_decode($userInfo["settings"], TRUE);
            $_SESSION['recentClients'] = $_SESSION['userSettings']['recentClients'];
        }
        else{
            $_SESSION["userSettings"]["recentClients"] = ['-1', '-1', '-1'];
            $_SESSION["userSettings"]["isDarkMode"] = TRUE;
        }
        
        header('Location: /ASCapstone/main.php');
        exit();
    }
    else {
        return FALSE;
    }
    
}

function getTransByGroup($clientID, $transGroup, $scheduleType, $dateStart, $dateEnd) {
    global $db;
    $results = [];

    $query = $db->prepare("SELECT * FROM transactions WHERE transGroup = :transGroup AND clientID = :clientID AND transType = :scheduleType AND transDate BETWEEN :dateStart AND :dateEnd ORDER BY transDate ASC;");
    $binds = array(
        ":clientID" => $clientID,
        ":transGroup" => $transGroup,
        ":scheduleType" => $scheduleType,
        ":dateStart" => $dateStart,
        ":dateEnd" => $dateEnd
);


    if($query->execute($binds) && $query->rowCount() > 0) {
        $results = $query->fetchAll(PDO::FETCH_ASSOC);
    }
    else {
        $results = FALSE;
    }

    return $results;
}

?>