const BUTT_SAVE = 0;
const BUTT_CLEAR = 1;
const BUTT_EDIT = 2;
const BUTT_DEL = 3;


console.log(transIDBox);
const buttArray = document.querySelectorAll(`.transButt`);

var transIDBox = document.querySelector('#transID');
if(transIDBox.value == "-1"){
    document.querySelector('#delTrans').classList.add('hidden');
    document.querySelector('#editTrans').classList.add('hidden');
}





//print button
var printButt = document.querySelector('#printScheduleButt');
printButt.addEventListener('click', ()=> {
    const changePane = document.querySelector("#leftPanelToggle");
    changePane.value = "print";
});

// enable/disable fieldset
var transType = document.querySelector('#transType');

transType.addEventListener('change', () => {
    const depField = document.querySelector('#depField');
    const witField = document.querySelector('#witField');

    if(transType.value == 'inventory' || transType.value == 'income' || transType.value == "transfers"){
        depField.removeAttribute('disabled');
    }
    else{
        const textWipe = document.querySelectorAll('#depField input');
        textWipe.forEach(box =>{
            box.value = "";
        });
        depField.setAttribute('disabled', 'disabled');
    }
    if(transType.value == 'expenses' || transType.value == 'transfers'){
        witField.removeAttribute('disabled');
    }
    else{
        witField.setAttribute('disabled', 'disabled');
        const textWipe = document.querySelectorAll('#witField input');
        textWipe.forEach(box =>{
            box.value = "";
        });
    }

});

//Auto fill bank
var autoDep = document.querySelectorAll('#depField input');
var autoWit = document.querySelectorAll('#witField input');

//Auto Deposit
autoDep.forEach(autoBox => {
    autoBox.addEventListener('change', () => {
        var autoBanks = document.querySelectorAll('#bankSelect option');

        autoBanks.forEach(banks => {

            if(banks.value != -1){

                var splitBank = banks.innerText.split(/[.-]/);
                var splitLower = [];

                splitBank[0] = splitBank[0].trim()
                splitBank[1] = splitBank[1].trim()
                splitBank[2] = splitBank[2].trim()

                splitLower[0] = splitBank[0].toLowerCase();
                splitLower[1] = splitBank[1].toLowerCase();
                splitLower[2] = splitBank[2].toLowerCase();


                if(splitLower.includes(autoBox.value.toLowerCase())){

                    autoDep[1].value = splitBank[0];
                    autoDep[2].value = splitBank[1];
                    autoDep[3].value = splitBank[2];
                    if(document.querySelector('#witField').disabled){
                        document.querySelector('#checkNum').focus();
                    }
                    else{
                        document.querySelector('#bankWitID').focus();
                    }
                }
            }

        });
    });
});

// Auto Withdraw
autoWit.forEach(autoBox => {
    autoBox.addEventListener('change', () => {
        var autoBanks = document.querySelectorAll('#bankSelect option');

        autoBanks.forEach(banks => {

            if(banks.value != -1){

                var splitBank = banks.innerHTML.split(/[.;-]/);
                var splitLower = banks.innerHTML.split(/[.;-]/);
                console.log(splitBank);

                splitBank[0] = splitBank[0].trim()
                splitBank[1] = splitBank[1].trim()
                splitBank[2] = splitBank[2].trim()

                splitLower[0] = splitBank[0].toLowerCase();
                splitLower[1] = splitBank[1].toLowerCase();
                splitLower[2] = splitBank[2].toLowerCase();


                if(splitLower.includes(autoBox.value.toLowerCase())){

                    autoWit[1].value = splitBank[0];
                    autoWit[2].value = splitBank[1];
                    autoWit[3].value = splitBank[2];
                    document.querySelector('#checkNum').focus();
                }
            }

        });
        console.log(autoBanks);
    });
});



function validateForm() {
    transName = document.querySelector(`#transName`);
    transAmount = document.querySelector(`#transAmount`);
    transDate = document.querySelector(`#transDate`);
    transType = document.querySelector(`#transType`);
    transGroup = document.querySelector(`#transGroup`);
    bankDepID = document.querySelector(`#bankDepID`);
    bankWitID = document.querySelector(`#bankWitID`);
    bankDepName = document.querySelector(`#bankDepName`);
    bankDepNum = document.querySelector(`#bankDepNum`);
    bankWitName = document.querySelector(`#bankWitName`);
    bankWitNum = document.querySelector(`#bankWitNum`);
    transCheckNum = document.querySelector(`#transCheckNum`);
    transMemo = document.querySelector(`#transMemo`);

    if (document.forms["transForm"]["transName"].value != "") {
        let pattern = /^[A-Za-z0-9\s\-\.,&]+$/;
        let text = document.forms["transForm"]["transName"].value;
        
        if (pattern.test(text)) {
            //passed validation
        }
        else {
            //failed validation
        }
    }
    else {
        //failed validation
    }

    if (document.forms["transForm"]["transAmount"].value != "") {
        let pattern = /^\$?\d{1,3}(?:,\d{3})*(?:\.\d{2})?$/;
        let text = document.forms["transForm"]["transAmount"].value;
        
        if (pattern.test(text)) {
            //passed validation
        }
        else {
            //failed validation
        }
    }
    else {
        //failed validation
    }

    if (document.forms["transForm"]["transDate"].value != "") {
        //passed validation
    }
    else {
        //failed validation
    }

    if (document.forms["transForm"]["transType"].value != "") {
        //passed validation
    }
    else {
        //failed validation
    }

    if (document.forms["transForm"]["transGroup"].value != "") {
        let pattern = /^[\S]{1,25}$/;
        let text = document.forms["transForm"]["transGroup"].value;
        
        if (pattern.test(text)) {
            //passed validation
        }
        else {
            //failed validation
        }
    }
    else {
        //failed validation
    }

    if (document.forms["transForm"]["bankDepID"].value != "") {
        let pattern = /^\d{1,4}$/;
        let text = document.forms["transForm"]["bankDepID"].value;
        
        if (pattern.test(text)) {
            //passed validation
        }
        else {
            //failed validation
        }
    }
    else {
        //failed validation
    }

    if (document.forms["transForm"]["bankWitID"].value != "") {
        let pattern = /^\d{1,4}$/;
        let text = document.forms["transForm"]["bankWitID"].value;
        
        if (pattern.test(text)) {
            //passed validation
        }
        else {
            //failed validation
        }
    }
    else {
        //failed validation
    }

    if (document.forms["transForm"]["bankDepName"].value != "") {
        let pattern = /^[\S]{1,25}$/;
        let text = document.forms["transForm"]["bankDepName"].value;
        
        if (pattern.test(text)) {
            //passed validation
        }
        else {
            //failed validation
        }
    }
    else {
        //failed validation
    }

    if (document.forms["transForm"]["bankWitName"].value != "") {
        let pattern = /^[\S]{1,25}$/;
        let text = document.forms["transForm"]["bankWitName"].value;
        
        if (pattern.test(text)) {
            //passed validation
        }
        else {
            //failed validation
        }
    }
    else {
        //failed validation
    }

    if (document.forms["transForm"]["bankDepNum"].value != "") {
        let pattern = /^\d{1,4}$/;
        let text = document.forms["transForm"]["bankDepNum"].value;
        
        if (pattern.test(text)) {
            //passed validation
        }
        else {
            //failed validation
        }
    }
    else {
        //failed validation
    }

    if (document.forms["transForm"]["bankWitNum"].value != "") {
        let pattern = /^\d{1,4}$/;
        let text = document.forms["transForm"]["bankWitNum"].value;
        
        if (pattern.test(text)) {
            //passed validation
        }
        else {
            //failed validation
        }
    }
    else {
        //failed validation
    }

    if (document.forms["transForm"]["transCheckNum"].value != "") {
        let pattern = /^\d{1,8}$/;
        let text = document.forms["transForm"]["transCheckNum"].value;
        
        if (pattern.test(text)) {
            //passed validation
        }
        else {
            //failed validation
        }
    }
    else {
        //failed validation
    }

    if (document.forms["transForm"]["transMemo"].value != "") {
        let pattern = /^.{1,250}$/;
        let text = document.forms["transForm"]["transMemo"].value;
        
        if (pattern.test(text)) {
            //passed validation
        }
        else {
            //failed validation
        }
    }
    else {
        //failed validation
    }


}