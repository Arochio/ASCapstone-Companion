<?php
ignore_user_abort(TRUE);
set_time_limit(0);
global $db;
//uses navigator.sendBeacon() in js to send array here
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SESSION["userID"]) && isset($_SESSION["recentClients"])) {
    // if(connection_aborted()) {
        $userID = $_SESSION["userID"];
        $recentClients = $_SESSION["recentClients"];
        $data = file_get_contents('php://input');

        //encode settings from js and recentClients to json
        $json = json_encode(array('isDarkMode' => $data[0], 'fontSize' => $data[1], 'recentClients' => $recentClients));

        $query = $db->prepare("UPDATE users SET settings = :s WHERE userID = :u;");

        $binds = array(
            ":s" => $json,
            ":u" => $userID
        );

        if($query->execute($binds) && $query->rowCount() > 0) {
            logout();
        }
    // }
}
?>