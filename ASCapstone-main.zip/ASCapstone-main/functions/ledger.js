document.querySelectorAll('.tr').forEach(tableRow => {
    tableRow.addEventListener('dblclick', () => {

            const depField = document.querySelector('#depField');
            const witField = document.querySelector('#witField');
            witField.removeAttribute('disabled');
            depField.removeAttribute('disabled');

            const transID = tableRow.id;
            const transJSON = JSON.parse(tableRow.children[tableRow.children.length - 1].innerText);
            const transForm = document.getElementById('transForm');
            const transFormData = new FormData(transForm);
            var isStopped = false;

            for (const [name, value] of transFormData.entries()) {
                if(value !== '' && value !== '-1') {
                    if(!window.confirm("Transaction creation in progress: Are you sure you want to clear data?")){
                        isStopped = true;
                        break;
                    }
                    else {
                        break;
                    }
                }
            }

            if(!isStopped){ 

                for (const [name] of transFormData.entries()) {
                    console.log(`name ${name} json ${transJSON}`);

                    if(name == "bankIn" && transJSON[name] !== null) {
                        var option = document.getElementById(`bank${transJSON[name]}`).innerText;
                        var splitBank = option.split(/[.-]/);
                        splitBank[0] = splitBank[0].trim();
                        splitBank[1] = splitBank[1].trim();
                        splitBank[2] = splitBank[2].trim();
                        document.getElementById('bankDepID').value = splitBank[0];
                        document.getElementById('bankDepName').value = splitBank[1];
                        document.getElementById('bankDepNum').value = splitBank[2];
                        
                    }

                    if(name == "bankOut" && transJSON[name] !== null) {
                        var option = document.getElementById(`bank${transJSON[name]}`).innerText;
                        var splitBank = option.split(/[.;-]/);
                        splitBank[0] = splitBank[0].trim();
                        splitBank[1] = splitBank[1].trim();
                        splitBank[2] = splitBank[2].trim();
                        document.getElementById('bankWitID').value = splitBank[0];
                        document.getElementById('bankWitName').value = splitBank[1];
                        document.getElementById('bankWitNum').value = splitBank[2];
                    }
                    else if(transJSON[name] && name != "bankIn") {
                        document.querySelector(`[name="${name}"]`).value = transJSON[name];
                    }


                    if(transType.value == 'inventory' || transType.value == 'income' || transType.value == "transfers"){
                        depField.removeAttribute('disabled');
                    }
                    else{
                        const textWipe = document.querySelectorAll('#depField input');
                        textWipe.forEach(box =>{
                            box.value = "";
                        });
                        depField.setAttribute('disabled', 'disabled');
                    }
                    if(transType.value == 'expenses' || transType.value == 'transfers'){
                        witField.removeAttribute('disabled');
                    }
                    else{
                        witField.setAttribute('disabled', 'disabled');
                        const textWipe = document.querySelectorAll('#witField input');
                        textWipe.forEach(box =>{
                            box.value = "";
                        });
                    }
                    
                }
                document.querySelector('#delTrans').classList.remove('hidden');
                document.querySelector('#editTrans').classList.remove('hidden');

            }
    });
});

document.querySelectorAll('.tr').forEach(tableRow => {
    tableRow.addEventListener('click', () => {
        document.querySelectorAll('.selectedRow').forEach(selectedRow => {
            selectedRow.classList.remove('selectedRow');
        });
        tableRow.classList.add('selectedRow');
    });
});

window.addEventListener('load', (e) => {
    document.querySelector('#bankSelect').addEventListener('change', updateLedger);
})



function updateLedger(event = '') {
    var currentBank = document.querySelector('#bankSelect').value;
    var tableRows = document.querySelectorAll('.tr');
    var endDate = document.querySelector('#endDate').value;
    var startDate = document.querySelector('#startDate').value;
    tableRows.forEach(tableRow => {
        var transDate = JSON.parse(tableRow.lastElementChild.innerText)["transDate"];
        var tempBankIn = JSON.parse(tableRow.lastElementChild.innerText)["bankIn"];
        var tempBankOut = JSON.parse(tableRow.lastElementChild.innerText)["bankOut"];
        if(tempBankIn == currentBank || tempBankOut == currentBank || currentBank == '-1') {
            if((startDate == '' || transDate >= startDate) && (transDate <= endDate || endDate == '')) {
                tableRow.classList.remove('hidden');
                tableRow.classList.add('show')
            }
            else {
                tableRow.classList.add('hidden');
                tableRow.classList.remove('show')
            }
        }
        else {
            tableRow.classList.add('hidden');
            tableRow.classList.remove('show');
        }
    });

}

var lastTab = document.querySelector('#ledgerPop');
lastTab.addEventListener('focus', () =>{
    document.querySelector('#transName').focus();
});