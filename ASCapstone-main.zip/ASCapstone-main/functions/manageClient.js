var selectedClient = document.querySelector('#clientInfo');
console.log(selectedClient.value);

if(selectedClient.value == ""){
    console.log("clientInfo is emptry");
    document.querySelector('#delClient').classList.add("hidden");
    document.querySelector('#reactivateClient').classList.add('hidden');
    document.querySelector('#editClient').classList.add('hidden');

}
else{
    document.querySelector('#newClient').classList.add("hidden");
    selectedClient = JSON.parse(selectedClient.value);
    console.log(selectedClient);
    const clientForm = document.querySelector('#clientForm');
    const clientFormData = new FormData(clientForm);
    for (const [name] of clientFormData.entries()) {
        console.log(name);
        document.querySelector(`[name="${name}"]`).value = selectedClient[0][name];
    }
    console.log(selectedClient[0]['isActive']);
    if(selectedClient[0]['isActive'] == 1){
        document.querySelector('#reactivateClient').classList.add("hidden");
    }
    else{
        document.querySelector('#delClient').classList.add('hidden');
    }
}

