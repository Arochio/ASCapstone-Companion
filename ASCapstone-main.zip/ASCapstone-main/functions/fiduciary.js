var select = document.querySelector('#fidDrop');
var fidForm
console.log(select);
select.addEventListener('change', (e) => {
    var currentFid = e.target.value;
    if(currentFid == -1){
        //clear the form here
        document.querySelector('#fidLName').value = "";
        document.querySelector('#fidFName').value = "";
        document.querySelector('#fidMName').value = "";
        document.querySelector('#fidTitle').value = "";
        document.querySelector('#fidAddress').value = "";
        document.querySelector('#fidCity').value = "";
        document.querySelector('#fidState').value = "CT";
        document.querySelector('#fidZip').value = "";
        document.querySelector('#fidPhone').value = "";
        document.querySelector('#fiduciaryID').value = "";

        document.querySelector('#addFid').classList.remove('hidden');

        document.querySelector('#editFid').classList.add('hidden');
        document.querySelector('#delFid').classList.add('hidden');
    }
    else if (currentFid == 0) {  
    }
    else{
        currentFid = JSON.parse(currentFid);
        const fidForm = document.querySelector('#fidForm');
        const fidFormData = new FormData(fidForm);
        for (const [name] of fidFormData.entries()) {
            document.querySelector(`[name="${name}"]`).value = currentFid[name];
            
        }
        document.querySelector('#addFid').classList.add('hidden');

        document.querySelector('#editFid').classList.remove('hidden');
        document.querySelector('#delFid').classList.remove('hidden');
    }

});