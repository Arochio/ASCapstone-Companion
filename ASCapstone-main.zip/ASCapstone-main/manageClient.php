<?php include("includes/head.php");?>
<?php include("includes/header.php");?>

<?php
    $fidList = getFiduciary();

    // Variables
    $clientLName = "";
    $clientMName = "";
    $clientFName = "";
    $clientBirth = "";
    $clientDeath = "";
    $clientAddress = "";
    $clientCity = "";
    $clientState = "CT";
    $clientZip = "";
    $clientCaseNum = "";
    $clientAppointment = "";
    $fiduciaryName = "";
    $clientID = "";

    if(isset($_POST['newClient']) || isset($_POST['editClient'])){
        $feedback = "";
        echo('this worked');
        
        if($_POST["clientLName"] != "") {$clientLName = filter_input(INPUT_POST,"clientLName");} else {$feedback .= "Last Name, ";}
        $clientMName = filter_input(INPUT_POST, "clientMName");
        if($_POST["clientFName"] != "") {$clientFName = filter_input(INPUT_POST,"clientFName");} else {$feedback .= "First Name, ";}
        if($_POST["dateBirth"] != "") {$clientBirth = filter_input(INPUT_POST,"dateBirth");} else {$feedback .= "Date of Birth, ";}
        $clientDeath = filter_input(INPUT_POST, "dateDeath");
        $clientAddress = filter_input(INPUT_POST, "clientAddress");
        $clientCity = filter_input(INPUT_POST, "clientCity");
        // $clientState = filter_input(INPUT_POST, "clientState");
        $clientState = "CT";
        $clientZip = filter_input(INPUT_POST, "clientZip");
        if($_POST["caseNum"] != "") {$clientCaseNum = filter_input(INPUT_POST,"caseNum");} else {$feedback .= "Case Number, ";}
        if($_POST["dateAppt"] != "") {$clientAppointment = filter_input(INPUT_POST,"dateAppt");} else {$feedback .= "Appointment Date, ";}

        if($_POST["fiduciaryID"] != "") {$fiduciaryName = filter_input(INPUT_POST,"fiduciaryID");} else {$feedback .= "Fiduciary Name, ";}
        $clientID = filter_input(INPUT_POST, "clientID");

        if($feedback === ""){

            if(isset($_POST['newClient'])){
                $isSuccessful = addClient($fiduciaryName, $clientFName, $clientMName, $clientLName, $clientAppointment, $clientBirth, $clientDeath, $clientCaseNum, $clientAddress, $clientCity, $clientState, $clientZip);

                if($isSuccessful === "Client Added."){
                    $clientLName = "";
                    $clientMName = "";
                    $clientFName = "";
                    $clientBirth = "";
                    $clientDeath = "";
                    $clientAddress = "";
                    $clientCity = "";
                    $clientState = "CT";
                    $clientZip = "";
                    $clientCaseNum = "";
                    $clientAppointment = "";
                    $fiduciaryName = "";
                }
                else{
                    echo("There was an error with adding the client somewhere");
                }
            }
            else{
                echo('<script>alert("' . $fiduciaryName . ' ' . $clientFName . ' ' . $clientMName . ' ' . $clientLName . ' ' . $clientAppointment . ' ' . $clientBirth . ' ' . $clientDeath . ' ' . $clientCaseNum . ' ' . $clientAddress . ' ' . $clientCity . ' ' . $clientState . ' ' . $clientZip . ' ' . $clientID .'"</script>');
                editClient($fiduciaryName, $clientFName, $clientMName, $clientLName, $clientAppointment, $clientBirth, $clientDeath, $clientCaseNum, $clientAddress, $clientCity, $clientState, $clientZip, $clientID);
            }

        }
        else{
            echo($feedback);
        }

    }
    else if(isset($_POST['delClient'])){
        $clientID = filter_input(INPUT_POST, "clientID");
        activateClient(0,$clientID);
    }
    else if(isset($_POST['reactivateClient'])){
        $clientID = filter_input(INPUT_POST, "clientID");
        activateClient(1,$clientID);
    }
    else if(isset($_POST["clearClient"])){
        $clientLName = "";
        $clientMName = "";
        $clientFName = "";
        $clientBirth = "";
        $clientDeath = "";
        $clientAddress = "";
        $clientCity = "";
        $clientState = "CT";
        $clientZip = "";
        $clientCaseNum = "";
        $clientAppointment = "";
        $fiduciaryName = "";
        header('Location: /ASCapstone/manageClient.php');

    }



?>
<body>  
    <main id="manageClients">
        <div id="clientManager" style="width:60%; padding-left:20px;">
            
            <div class="flex" style="justify-content:space-between;">
                <form method="POST" id="clientForm" name="clientForm">
                    <h3>Client Info</h3>
                    
                    <input type="hidden" id="clientInfo" name="clientInfo" value='<?php
                        if(isset($_GET["clientID"])):
                            $clientJSON = json_encode(getOneClient($_GET["clientID"]));
                            echo($clientJSON);
                        ?>
                    <?php endif;?>'>
                    <input type="hidden" id="clientID" name="clientID" value="<?=$clientID?>">   
                    
                    <hr>
                    <div class="transRow">
                        <div>
                            <label for="clientLName">Last Name</label>
                            <input type="text" id="clientLName" name="clientLName">
                        </div>
                        <div>
                            <label for="clientMName">Middle Name</label>
                            <input type="text" id="clientMName" name="clientMName">
                        </div>
                        <div>
                            <label for="clientFName">First Name</label>
                            <input type="text" id="clientFName" name="clientFName">
                        </div>
                        
                    </div>
                    <div class="transRow">
                        <div>
                            <label for="dateBirth">Date of Birth</label>
                            <input type="date" id="dateBirth" name="dateBirth">
                        </div>
                        <div>
                            <label for="dateDeath">Date of Death</label>
                            <input type="date" id="dateDeath" name="dateDeath">                            
                        </div>
                    </div>
                    <div class="transRow">
                        <div>
                            <label for="clientAddress">Address</label>
                            <input type="text" id="clientAddress" name="clientAddress">                            
                        </div>
                        <div>
                            <label for="clientCity">City</label>
                            <input type="text" id="clientCity" name="clientCity">                            
                        </div>
                    </div>
                    <div class="transRow">
                        <div>
                            <label for="clientState">State</label>
                            <input type="text" id="clientState" name="clientState" minlength="2" maxlength="2" value="CT" disabled>                            
                        </div>
                        <div>
                            <label for="clientZip">Zipcode</label>
                            <input type="text" id="clientZip" name="clientZip">                            
                        </div>
                    </div>



                   


                    <label for="caseNum">Probate Case Number</label>
                    <input type="text" id="caseNum" name="caseNum">
                    <label for="dateAppt">Date of Appointment</label>
                    <input type="date" id="dateAppt" name="dateAppt">

                    <label for="fiduciaryID">Fiduciary</label>
                    <select id="fiduciaryID" name="fiduciaryID">
                        <option value="0">Select a fiduciary</option>
                        <?php foreach($fidList as $fid):?>
                            <option value='<?=$fid["fiduciaryID"]?>' id="fid<?=$fid["fiduciaryID"]?>" name="fid<?=$fid["fiduciaryID"]?>"><?= $fid["fidFName"]?> <?= $fid["fidLName"]?></option>
                        <?php endforeach;?>
                    </select>
                    <div class="transButtRow" style="padding-top:10px;">
                        <button type="submit" name="newClient" id="newClient" class="transButt accept">New Client</button>
                        <button type="submit" name="clearClient" id="clearClient" class="transButt deny">Clear Client</button>
                        <button type="submit" name="editClient" id="editClient" class="transButt accept">Edit Client</button>
                        <button type="submit" name="reactivateClient" id="reactivateClient" class="transButt accept">Reactivate Client</button>
                        <button type="submit" name="delClient" id="delClient" class="transButt deny">Deactivate Client</button>                      
                    </div>
                </form>
                <div style="align-self:flex-end;">
                    <button onclick="window.location.href='main.php';" class="transButt" >
                        Return to Main Menu
                    </button>
                </div>
                    

            </div>
            
        </div>
        <?php include("includes/clientList.php");?>

    </main>
</body>
<script src="functions/manageClient.js"></script>