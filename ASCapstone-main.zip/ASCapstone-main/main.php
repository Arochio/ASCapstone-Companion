<?php include("includes/head.php");?>
<body>

    <!----------HEADER-------------->
    <?php include("includes/header.php");?>
    <main class="flex">
        <?php 
            if(isset($_GET['mode'])){
                $_SESSION['mode'] = $_GET['mode'];
            }
            if(isset($_SESSION['mode'])){
                if($_SESSION['mode'] == "trans"){
                    include("includes/transactions.php");
                }
                else{
                    include("includes/selectSchedules.php");
                }
            }
            else{
                include("includes/transactions.php");
            }
        ?>
        <?php include("includes/ledger.php");?>
        <?php include("includes/clientList.php");?>
    </main>
</body>
<?php include('includes/footer.php'); ?>
</html>