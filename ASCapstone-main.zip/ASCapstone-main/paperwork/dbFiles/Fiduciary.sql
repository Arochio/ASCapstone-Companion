CREATE TABLE `sys`.`fiduciary` (
  `fiduciaryID` SMALLINT NOT NULL AUTO_INCREMENT,
  `fidFName` VARCHAR(20) NULL,
  `fidMName` VARCHAR(20) NULL,
  `fidLName` VARCHAR(45) NULL,
  `address` VARCHAR(45) NULL,
  `city` VARCHAR(45) NULL,
  `state` VARCHAR(2) NULL,
  `zip` INT NULL,
  `title` VARCHAR(45) NULL,
  `phone` VARCHAR(12) NULL,
  PRIMARY KEY (`fiduciaryID`),
  UNIQUE INDEX `fiduciaryID_UNIQUE` (`fiduciaryID` ASC) VISIBLE);