CREATE TABLE `sys`.`transactions` (
  `transID` INT NOT NULL AUTO_INCREMENT,
  `transType` VARCHAR(12) NULL,
  `transName` VARCHAR(30) NULL,
  `memo` VARCHAR(500) NULL,
  `transDate` DATE NULL,
  `amount` FLOAT NULL,
  `bankIn` INT NULL,
  `bankOut` INT NULL,
  `checkNum` INT NULL,
  `transGroup` VARCHAR(45) NULL,
  PRIMARY KEY (`transID`),
  UNIQUE INDEX `transID_UNIQUE` (`transID` ASC) VISIBLE);