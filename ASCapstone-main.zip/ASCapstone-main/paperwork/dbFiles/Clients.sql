CREATE TABLE `sys`.`clients` (
 `clientID` SMALLINT NOT NULL,
 `fiduciaryID` INT,
 `clientFName` VARCHAR(45),
 `clientMName` VARCHAR(45),
 `clientLName` VARCHAR(45),
 `dateAppt` DATE,
 `dateBirth` DATE,
 `dateDeath` DATE,
 `caseNum` INT,
 `address` VARCHAR(45) NULL,
 `city` VARCHAR(45) NULL,
 `state` VARCHAR(2) NULL,
 `zip` INT NULL,

  PRIMARY KEY (`clientID`),
  UNIQUE INDEX `clientID_UNIQUE` (`clientID` ASC) VISIBLE,
  UNIQUE INDEX `caseNum_UNIQUE` (`caseNum` ASC) VISIBLE);