CREATE TABLE `sys`.`banks` (
  `bankID` SMALLINT NOT NULL AUTO_INCREMENT,
  `clientID` INT NULL,
  `bankName` VARCHAR(45) NULL,
  `bankNum` INT NULL,
  PRIMARY KEY (`bankID`),
  UNIQUE INDEX `bankID_UNIQUE` (`bankID` ASC) VISIBLE);