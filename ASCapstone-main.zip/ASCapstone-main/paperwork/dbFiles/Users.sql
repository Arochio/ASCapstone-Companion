CREATE TABLE `sys`.`users` (
  `userID` SMALLINT NOT NULL,
  `username` VARCHAR(45) NOT NULL,
  `userPass` VARCHAR(45) NOT NULL,
  `displayname` VARCHAR(20) NOT NULL,
  `isAdmin` TINYINT(1) NOT NULL DEFAULT 0,
  `settings` JSON,
  PRIMARY KEY (`userID`),
  UNIQUE INDEX `idusers_UNIQUE` (`userID` ASC) VISIBLE,
  UNIQUE INDEX `username_UNIQUE` (`username` ASC) VISIBLE);