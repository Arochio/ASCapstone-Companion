<?php

        //Store on page load
        $fidList = getFiduciary();

        $fidLName = "";
        $fidFName = "";
        $fidMName = "";
        $fidTitle = "";
        $fidAddress = "";
        $fidCity = "";
        if(isset($_POST["fiduciaryID"])) {$fiduciaryID = $_POST['fiduciaryID'];} else {$fiduciaryID = "";}

        // Change this when expanding out of CT
        $fidState = "CT";
        $fidZip = "";
        $fidPhone = "";
    function clearFid(){
        global $fidLName, $fidFName, $fidMName, $fidTitle, $fidAddress, $fidCity, $fidState, $fidZip, $fidPhone; 
        $fidLName = "";
        $fidFName = "";
        $fidMName = "";
        $fidTitle = "";
        $fidAddress = "";
        $fidCity = "";
        $fiduciaryID = "";

        // Change this when expanding out of CT
        $fidState = "CT";
        $fidZip = "";
        $fidPhone = "";
    }
    //--------------- ADD/EDIT--------------------
    if(isset($_POST['addFid']) || isset($_POST['editFid'])){
        
        $feedback = "";

        if($_POST["fidLName"] != "") {$fidLName = filter_input(INPUT_POST,"fidLName");} else {$feedback .= "Last Name, ";}
        if($_POST["fidFName"] != "") {$fidFName = filter_input(INPUT_POST,"fidFName");} else {$feedback .= "First Name, ";}
        
        $fidMName = filter_input(INPUT_POST, "fidMName");
        $fidTitle = filter_input(INPUT_POST, "fidTitle");

        if($_POST["fidAddress"] != "") {$fidAddress = filter_input(INPUT_POST,"fidAddress");} else {$feedback .= "Address, ";}
        if($_POST["fidCity"] != "") {$fidCity = filter_input(INPUT_POST,"fidCity");} else {$feedback .= "City, ";}
        if($_POST["fidState"] != "") {$fidState = filter_input(INPUT_POST,"fidState");} else {$feedback .= "State, ";} 
        if($_POST["fidZip"] != "") {$fidZip = filter_input(INPUT_POST,"fidZip");} else {$feedback .= "Zipcode, ";}
        if($_POST["fidPhone"] != "") {$fidPhone = filter_input(INPUT_POST,"fidPhone");} else {$feedback .= "Phone Number, ";}

        if($feedback == ""){
            if(isset($_POST['addFid'])){
                addFiduciary($fidFName, $fidMName, $fidLName, $fidAddress, $fidCity, $fidState, $fidZip, $fidTitle, $fidPhone);
                echo('<script>window.location.href = window.location.href;</script>');
            }
            else if(isset($_POST['editFid'])){
                editFiduciary($fidFName, $fidMName, $fidLName, $fidAddress, $fidCity, $fidState, $fidZip, $fidTitle, $fidPhone, $fiduciaryID);
                echo('<script>window.location.href = window.location.href;</script>');
            }
        }
    }

    // --------------CLEAR---------------------
    else if(isset($_POST['clearFid'])){
        //Add a confirm popup?
        clearFid();
    }

    // --------------DELETE------------
    else if(isset($_POST['delFid'])){
        // Add a confirm popup?
        delFiduciary($fiduciaryID);
    }

?>

<div id="manageFiduciaries">
    <div class="setHead">
        <h3>Fiduciary Info</h3>
        <select name="fidDrop" id="fidDrop" class="dropInput">
            <option value="0">Select a fiduciary</option>
            <!-- put existing fiduciaries here to populate for edit -->
            <?php
            foreach($fidList as $fid):
                $fidJSON = json_encode($fid);?>

                <option value='<?=$fidJSON?>' id="fid<?=$fid["fiduciaryID"]?>" name="fid<?=$fid["fiduciaryID"]?>"><?= $fid["fidFName"]?> <?= $fid["fidLName"]?></option>
            <?php endforeach;?>
            <option value="-1">New Fiduciary</option>
        </select>
    </div>
    <hr>
    <form method="POST" id="fidForm" name="fidForm">

        <div class="transRow">
            <div>
                <label for="fidLName">Last Name</label>
                <input type="text" name="fidLName" id="fidLName" value=<?=$fidLName?>>
            </div>
            <div>
                <label for="fidFName">First Name</label>
                <input type="text" name="fidFName" id="fidFName" value=<?=$fidFName?>>
            </div>
        </div>

        <div class="transRow">
            <div>
                <label for="fidMName">Middle Name</label>
                <input type="text" name="fidMName" id="fidMName" value=<?=$fidMName?>>
            </div>
            <div>
                <label for="fidTitle">Title</label>
                <input type="text" name="fidTitle" id="fidTitle" value=<?=$fidTitle?>>
            </div>
        </div>

        <div class="transRow">
            <div>
                <label for="fidAddress">Address</label>
                <input type="text" name="fidAddress" id="fidAddress" value=<?=$fidAddress?>>
            </div>
            <div>
                <label for="fidCity">City</label>
                <input type="text" name="fidCity" id="fidCity" value=<?=$fidCity?>>
            </div>
            <div>
                <label for="fidState">State</label>
                <input type="text" name="fidState" id="fidState" value=<?=$fidState?>>
            </div>
            <div>
                <label for="fidZip">Zipcode</label>
                <input type="text" name="fidZip" id="fidZip" value=<?=$fidZip?>>
            </div>
        </div>

        <div class="transRow">
            <div>
                <label for="fidPhone">Phone Number</label>
                <input type="text" name="fidPhone" id="fidPhone" value=<?=$fidPhone?>>
            </div>
            <div>
                <input type="hidden" name="fiduciaryID" id="fiduciaryID" value="">
            </div>
        </div>
        <div id="transButtRow">
            <button type="submit" value="addFid" name="addFid" id="addFid" class="transButt accept">New Fiduciary</button>
            <button type="submit" value="editFid" name="editFid" id="editFid" class="transButt accept">Edit Fiduciary</button>
            <button type="submit" value="clearFid" name="clearFid" id="clearFid" class ="transButt deny">Clear Fiduciary</button>
            <button type="submit" value="delFid" name="delFid" id="delFid" class="transButt deny">Delete Fiduciary</button>
        </div>
    </form>
</div>
<script src="functions/fiduciary.js"></script>