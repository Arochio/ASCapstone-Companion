<?php 
if(isset($_GET['clientID']) && !in_array($_GET['clientID'], $_SESSION['recentClients'])) {
    array_unshift($_SESSION['recentClients'], $_GET['clientID']);
    array_pop($_SESSION['recentClients']);
    $_SESSION['userSettings']['recentClients'] = $_SESSION['recentClients'];
}
?>
<div id="clientList">
    <div class="header">
        <a href="#" style="visibility:hidden;"><i class="fa-solid fa-arrow-up-right-from-square"></i></a>
        <h3>Client List</h3>
    </div>
    <!-- Search Bar -->
     <form id="clientSearchBar">
        <label for="clientSearch">Search</label>
        <input type="text" name="clientSearch" id="clientSearch" class="textInput"></input>
     </form>
    
    <!-- Recents List -->
    <!-- All this should be automated -->
    <p class="label" style="margin-left:10px">Recents</p>
    <div class="list" id="recentClients">
        <?php
        foreach($_SESSION['recentClients'] as $recent):
            if($recent != '-1'):
                $client = getOneClient($recent)[0];
        ?>
        <a class="clientDisplay" href="?clientID=<?=$client['clientID']?>">
            <p class="clientName"><?=$client['clientLName'] . ', ' . $client['clientFName']?></p>
            <p class="shyTxt clientNum"><?=$client['caseNum']?></p>
        </a>
        <?php 
        endif;
    endforeach; ?>

    </div>

    <hr>

    <div class = "list scroll" id="clientDisplay">

        <?php
        $clients = getActiveClients();
        if ($clients != "No Clients Found") {
            foreach ($clients as $client) { ?>

                <a class="clientDisplay" href="?clientID=<?=$client['clientID']?>">
                    <p class="clientName"><?=$client['clientLName'] . ', ' . $client['clientFName'];?></p>
                    <p class="shyTxt clientNum">#<?=$client['caseNum'];?></p>
                </a>

            <?php
            }
        }
        $inactiveClients = getInactiveClients();
        if($inactiveClients != "No Clients Found"){
            foreach ($inactiveClients as $client) { ?>

                <a class="clientDisplay" href="?clientID=<?=$client['clientID']?>">
                    <p class="shyTxt clientName"><?=$client['clientLName'] . ', ' . $client['clientFName'];?></p>
                    <p class="shyTxt clientNum">#<?=$client['caseNum'];?></p>
                </a>

            <?php
            }
        }
        if($clients == $inactiveClients){ ?>

            <div class="clientDisplay">
                <p>No clients found!</p>
                <p>Create clients to begin.</p>
            </div>

        <?php
        }
        ?>
    </div>
    <a href="manageClient.php"><i class="fa-solid fa-circle-plus"></i></a>
   
</div>
<script src="functions/clientList.js"></script>
