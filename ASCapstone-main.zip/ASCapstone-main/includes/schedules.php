<?php
$docName = $_SESSION['docName'];
?>

<div id="schedHeadCont">
    <p class="schedHead leftAlign"><?=$clientName?></p>
    <p class="schedHead centerAlign"><?=$docName?></p>
    <p class="schedHead rightAlign"><?=date("m/d/Y");?></p>
</div>
<hr class="hrHead">
<?php 
if($_SESSION['docName'] != 'Per Last Accounting'):
$scheduleTotal = 0;
$nonEmptyGroups = 0;
if($groups !== 'No Groups Found'):
foreach($groups as $group):
    $transactions = getTransByGroup($clientID, $group['transGroup'], $docName, $dateStart, $dateEnd);
    $groupAmount = 0;
    if($transactions !== FALSE):
    $nonEmptyGroups += 1; ?>
    <p class="groupHeader"><?= $group['transGroup']?></p>
    <?php foreach($transactions as $trans):
    $groupAmount += $trans['amount'];
    $scheduleTotal += $trans['amount'];
?>
    <div class="schedBodyCont">
        <p class="schedBody transDate"><?=$trans['transDate']?></p>
        <p class="schedBody transName"><?=$trans['transName']?></p>
        <p class="schedBody transAmount mono"><?='$' . number_format($trans['amount'], 2);?></p>
    </div>
<?php 
endforeach;
endif;
if($groupAmount != 0):?>
    <div class="groupResults">
        <p class="schedBody groupName"><?= $group['transGroup']?> Total:</p>
        <p class="schedBody groupAmount mono"><?='$' . number_format($groupAmount, 2);?></p>
    </div>
    <hr>
<?php
endif; 
endforeach; 
endif;
if($scheduleTotal != 0): ?>
    <div class="groupResults">
        <p class="schedBody leftAlign"><?=$docName?> Total:</p>
        <p class="schedBody rightAlign mono"><?=number_format($scheduleTotal, 2)?></p>
    </div>
<?php
endif;
if($nonEmptyGroups == 0):?>
    <p>No transactions meet the selected criteria.</p>
<?php 
endif; 
else :
?>
<div class="groupResults">
    <p></p>
    <p></p>
</div>
<?php
$combinedBanks = 0;
$bankCount = 0;
foreach($bankTotals as $bankName => $bankValue):
    $combinedBanks += $bankValue;
    $bankCount += 1;
?>
    <div class="groupResults">
        <p class="schedBody"><?=$bankName?></p>
        <p class="schedBody bankValue mono"><?=number_format($bankValue, 2)?></p>
    </div>
<?php 
endforeach;?>
<hr class="hrHead">
<div class="groupResults">
    <p class="schedBody">Number of Banks: <?=$bankCount?></p>
    <p class="schedBody combinedBanks mono">Total: <?=number_format($combinedBanks, 2)?></p>
</div>
<?php endif;?>
<div class="pageBreak"></div>