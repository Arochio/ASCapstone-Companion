<?php
$userLName = '';
$userFName = '';
$username = '';
$isAdmin = '';
$isValidUsername = TRUE;

if(isset($_POST['userLName'])) {
    $feedback = '';
    $errorFields = [];
    
    if(isset($_POST['userLName'])) {$userLName = filter_input(INPUT_POST, "userLName");} else {$feedback .= " userLName";}
    if(isset($_POST['userFName'])) {$userFName = filter_input(INPUT_POST, "userFName");} else {$feedback .= " userFName";}
    $userDisplayName = $userFName . ' ' . $userLName;
    if(isset($_POST['username'])) {$username = filter_input(INPUT_POST, "username");} else {$feedback .= " username";}
    if(isset($_POST['userPass'])) {$userPass = filter_input(INPUT_POST, "userPass");} else {$feedback .= " userPass";}
    if(isset($_POST['confirmPassword'])) {$confirmPassword = filter_input(INPUT_POST, "confirmPassword");} else {$feedback .= " confirmPassword";}
    if(isset($_POST['delUser'])) {$delUser = $_POST['delUser'];} else {$delUser = FALSE;}
    if(isset($_POST['editUser'])) {$editUser = $_POST['editUser'];} else {$editUser = FALSE;}
    $isAdmin = $_POST['isAdmin'];
    
    if($isAdmin == 'on') {
        $isAdmin = 1;
    }
    else {
        $isAdmin = 0;
    }
    
    if($feedback == '' && $userPass == $confirmPassword) {
        if($delUser) {
            if(delUser($delUser) != '') {
                // echo('<script>window.location.href = window.location.href;</script>');
            }
        }
        else if($editUser) {
            $editResult = editUser($username, $userPass, $userDisplayName, $isAdmin, $editUser);
        }
        else {
            if(addUser($username, $userPass, $userDisplayName, $isAdmin)) {
                
            }
            else {
                $username = '';
                $isValidUsername = FALSE;
            }
        }
    }
    else {
        $errorFields = explode(' ', $feedback);
    }
}

?>

<div id="userSettings">
    <div class="setHead">
        <h3>User Info</h3>
        <select name="userDrop" id="userDrop" class="dropInput">
            <option value="">Select a user</option>
            <?php
            $users = getUsers();
            if($users != "No Users Found") {
                foreach ($users as $user) { ?>
                <option id="<?=$user['userID']?>" value="<?=$user['userID']?>"><?=$user['displayName']?><?php if($user['isAdmin']) {echo(' (Admin)');}?></option>                    
                <?php
                }
            }
            ?>
            <!-- put existing users here to populate for edit -->
        </select>
    </div>
    <hr>
    <form id="userForm" method="POST">

        <div class="transRow">
            <div>
                <label for="userLName">Last Name</label>
                <input type="text" name="userLName" id="userLName" required value="<?php if(isset($_POST['userLName'])) {echo($_POST['userLName']);}?>">
            </div>
            <div>
                <label for="userFName">First Name</label>
                <input type="text" name="userFName" id="userFName" required value="<?php if(isset($_POST['userFName'])) {echo($_POST['userFName']);}?>">
            </div>
        </div>

        <div class="transRow">
            <div>
                <label for="username">Username</label>
                <input type="text" name="username" id="username" required value="<?php if(isset($_POST['username']) && $isValidUsername) {echo($_POST['username']);}?>" class="<?php if(!$isValidUsername) {echo('invalid');}?>">
                <p class="invalidMsg"><?php if(!$isValidUsername) {echo('Username already in use.');}?></p>
            </div>
        </div>

        <div class="transRow">
            <div>
                <label for="password">Password</label>
                <input type="text" name="userPass" id="userPass" required>
            </div>
            <div>
                <label for="confirmPassword">Confirm Password</label>
                <input type="text" name="confirmPassword" id="confirmPassword" required>
            </div>
        </div>

        <div class="transRow">
            <div>
                <label for="isAdmin">Admin?</label>
                <input type="checkbox" name="isAdmin" id="isAdmin" <?php if($isAdmin == '1') {echo('checked="checked"');}?>>
            </div>
        </div>
        <div id="transButtRow">
            <button type="submit" name="addUser" id="addUser" value="addUser" class="transButt accept">New User</button>
            <button type="submit" name="editUser" id="editUser" value="" class="transButt accept">Edit User</button>
            <button type="submit" name="delUser" id="delUser" value="" class="transButt deny">Delete User</button>
        </div>
    </form>
    <script>
            var select = document.querySelector('#userDrop');
            select.addEventListener('change', (e) => {
                var selUser = document.getElementById(e.target.value);
                var splitInner = selUser.innerText.split(' ');
                var userFName = document.querySelector('#userFName');
                var userLName = document.querySelector('#userLName');
                var isAdmin = document.querySelector('#isAdmin');
                if(splitInner[2] != '(Admin)') {
                    isAdmin.removeAttribute('checked');
                }
                else {
                    isAdmin.setAttribute('checked', 'checked');
                }
                userLName.value = splitInner[1];
                userFName.value = splitInner[0];
                var delUser = document.querySelector('#delUser');
                delUser.addEventListener('click', () => {
                    delUser.value = selUser.id;
                });
                var editUser = document.querySelector('#editUser');
                editUser.addEventListener('click', () => {
                    editUser.value = selUser.id;
                });
                document.querySelector('#username').value = "";
    });
    </script>
    <div>
        <button onclick="window.location.href='main.php';" class="transButt" >
        Return to Main Menu
        </button>
    </div>
</div>
