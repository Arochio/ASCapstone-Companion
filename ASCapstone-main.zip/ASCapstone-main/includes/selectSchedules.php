
<div id="schedules">
    <div id="scheduleHeader">
        <a style="display:hidden">.</a>
        <h3>Select Schedules</h3>

        <!-- make x button -->
        <a href="?mode=trans"><i class="fa-solid fa-circle-xmark"></i></a>
    </div>
    <div id="scheduleMain">
        <form method="POST" id="scheduleForm" name="scheduleForm" action="printSchedules.php" target="_blank">
            <div class="schOption">
                <label for="checkInv">Inventory</label>
                <input type="checkbox" class="checks" name="checkInv" id="checkInv">
            </div>
            <div class="schOption">
                <label for="checkPerLast">Per Last Accounting</label>
                <input type="checkbox" class="checks" name="checkPerLast" id="checkPerLast">
            </div>
            <div class="schOption">
                <label for="checkIncome">Income</label>
                <input type="checkbox" class="checks" name="checkIncome" id="checkIncome">
            </div>
            <div class="schOption">
                <label for="checkExpenses">Expenses</label>
                <input type="checkbox" class="checks" name="checkExpenses" id="checkExpenses">
            </div>
            <div class="schOption">
                <label for="checkTransfers">Transfers</label>
                <input type="checkbox" class="checks" name="checkTransfers" id="checkTransfers">
            </div>
            <div class="schOption">
                <label for="checkIsRange">Use Date Range</label>
                <input type="checkbox" class="checks" name="checkIsRange" id="checkIsRange">
            </div>
            <fieldset id="printDates">
                <legend>Date Range</legend>
                <div class="">
                    <label for="printStart">Start Date</label>
                    <input type="date" name="printStart" id="printStart">
                </div>
                <div class="" style="padding-left:10px;">
                    <label for="printEnd">End Date</label>
                    <input type="date" name="printEnd" id="printEnd">
                </div>   
            </fieldset>
                <button type="submit" name="printSch" id="printSch" value="send" class="transButt beeg accept">Print</button>
        </form>
    </div>
</div>
