<?php

include("functions/functions.php");
session_start();
// include("functions/shutdown.php");

if(!isset($_SESSION["isLoggedIn"])) {
    echo('<script>alert("head.php");</script>');
    header('Location: /ASCapstone/index.php');
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Change Document Title Per Page -->
    <title>AS Capstone Project</title>
    <link rel="stylesheet" href="styles/main.css">
    <link rel="stylesheet" href="styles/transactions.css">
    <link rel="stylesheet" href="styles/ledger.css">
    <link rel="stylesheet" href="styles/clientList.css">
    <link rel="stylesheet" href="styles/settings.css">

    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Libertinus+Mono&display=swap" rel="stylesheet">
    
    <script src="functions/shutdown.js"></script>

    <script src="https://kit.fontawesome.com/61a36f0003.js" crossorigin="anonymous"></script>

</head>