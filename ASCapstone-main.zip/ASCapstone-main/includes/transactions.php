<?php
if(isset($_GET['clientID'])) {
    $_SESSION['clientID'] = $_GET['clientID'];
}

$transNamePost = "";
$transAmountPost = "";
$transDatePost = "";
$transTypePost = "";
$transGroupPost = "";
$transDepIDPost = "";
$transDepPost = "";
$transDepNumPost = "";
$transWitIDPost = "";
$transWitPost = "";
$transWitNumPost = "";
$transCheckPost = "";
$transMemoPost = "";

if(isset($_POST['delTrans'])){


    // Add an alert to make sure you're sure first?

    delTrans($_POST["transID"]);
        $transNamePost = "";
        $transAmountPost = "";
        $transDatePost = "";
        $transTypePost = "";
        $transGroupPost = "";
        $transDepIDPost = "";
        $transDepPost = "";
        $transDepNumPost = "";
        $transWitIDPost = "";
        $transWitPost = "";
        $transWitNumPost = "";
        $transCheckPost = "";
        $transMemoPost = "";
}
else if (isset($_POST['clearTrans'])){
        
    // Add an alert to make sure you're sure first?

    $transNamePost = "";
    $transAmountPost = "";
    $transDatePost = "";
    $transTypePost = "";
    $transGroupPost = "";
    $transDepIDPost = "";
    $transDepPost = "";
    $transDepNumPost = "";
    $transWitIDPost = "";
    $transWitPost = "";
    $transWitNumPost = "";
    $transCheckPost = "";
    $transMemoPost = "";
}
else if(isset($_POST['newTrans']) || isset($_POST['editTrans'])){
    $feedback = "";

    // Required Fields: transName, Amount, date, type
    if($_POST["transName"] != "") {$transNamePost = filter_input(INPUT_POST,"transName");} else {$feedback .= "Transaction Name, ";}
    if($_POST["amount"] != "") {$transAmountPost = filter_input(INPUT_POST,"amount");} else {$feedback .= "Amount, ";}
    if($_POST["transDate"] != "") {$transDatePost = filter_input(INPUT_POST,"transDate");} else {$feedback .= "Date, ";}
    if($_POST["transType"] != "") {$transTypePost = filter_input(INPUT_POST,"transType");} else {$feedback .= "Transaction Type, ";}
    $transGroupPost = filter_input(INPUT_POST, "transGroup");
    $transDepNamePost = filter_input(INPUT_POST, "bankDepName");
    $transDepNumPost = filter_input(INPUT_POST, "bankDepNum");
    $transWitNamePost = filter_input(INPUT_POST, "bankWitName");
    $transWitNumPost = filter_input(INPUT_POST, "bankWitNum");
    $transCheckPost = filter_input(INPUT_POST, "checkNum");
    $transMemoPost = filter_input(INPUT_POST, "memo");
    $transIDPost = filter_input(INPUT_POST, "transID");
    $clientIDPost = filter_input(INPUT_POST, "clientID");

    if($transDepNamePost != "" && $transDepNumPost != "") {
        $bankDepID = getBankFromName($transDepNamePost, $transDepNumPost, $_SESSION['clientID']);
        if($bankDepID == -1) {
            addBank($_SESSION['clientID'], $transDepNamePost, $transDepNumPost);
            $bankDepID = getBankFromName($transDepNamePost, $transDepNumPost, $_SESSION['clientID']);
        }
        
    }
    else {
        $bankDepID = false;
    }

    if($transWitNamePost != "" && $transWitNumPost != "") {
        $bankWitID = getBankFromName($transWitNamePost, $transWitNumPost, $_SESSION['clientID']);
        if($bankWitID == -1) {
            addBank($_SESSION['clientID'], $transWitNamePost, $transWitNumPost);
            $bankWitID = getBankFromName($transWitNamePost, $transWitNumPost, $_SESSION['clientID']);
        }
    }
    else {
        $bankWitID = false;
    }

    // echo($feedback);
    // echo(filter_input(INPUT_POST,"bankDepName"));
    if($feedback === ""){
        // addTrans($transNamePost, $transAmountPost, $transDatePost, $transTypePost, $transGroupPost, filter_input(INPUT_POST,"bankDepName"),filter_input(INPUT_POST,"bankWitName"), filter_input(INPUT_POST,"transCheckNum"), filter_input(INPUT_POST,"transMemo"),filter_input(INPUT_POST,"clientID"));
       if(isset($_POST['newTrans'])){
            $isSuccessful = addTrans($transNamePost, $transAmountPost, $transDatePost, $transTypePost, $transGroupPost, $bankDepID, $bankWitID, $transCheckPost, $transMemoPost, $_SESSION['clientID']);
       }
       else{
            $isSuccessful = editTrans($clientIDPost,$transTypePost, $transNamePost, $transMemoPost, $transDatePost, $transAmountPost, $bankDepID, $bankWitID, $transCheckPost,$transGroupPost, $transIDPost);
       }
         if($isSuccessful == "Transaction Added." || $isSuccessful == "Transaction updated."){
            $transNamePost = "";
            $transAmountPost = "";
            $transDatePost = "";
            $transTypePost = "";
            $transGroupPost = "";
            $transDepIDPost = "";
            $transDepPost = "";
            $transDepNumPost = "";
            $transWitIDPost = "";
            $transWitPost = "";
            $transWitNumPost = "";
            $transCheckPost = "";
            $transMemoPost = "";
            echo('<script>window.location.href = window.location.href;</script>');
        }

    }
}
?>

<div id="transactions">
    <div class="header">
        <a href="#" style="visibility:hidden;"><i class="fa-solid fa-arrow-up-right-from-square"></i></a>
        <h3>Transactions</h3>
        <div class="flex lightTxt p5">
            Print Schedules
            <a href="?mode=print" id="printScheduleButt" style="margin-left: 5px"><i class="fa-solid fa-print"></i></a>
        </div>
        
    </div>
        <form method="POST" id="transForm" name="transForm">
        <fieldset id="fullFormField" <?php if(!isset($_SESSION['clientID'])){ ?> disabled <?php } ?>)>

            <!-- First Row -->
            <div class="transRow">
                <div>
                    <label for="transName">Transaction Name</label>
                    <input type="text" name="transName" id="transName" class="textInput" value="<?=$transNamePost?>">
                </div>
            </div>


            <!-- 2nd Row: Amount & Date -->
            <div class="transRow">
                <div>
                    <label for="amount">Amount</label>
                    <input type="number" name="amount" id="amount" class="textInput" value="<?=$transAmountPost?>" step="0.01">
                </div>
                <div>
                    <label for="transDate">Date</label>
                    <input type="date" name="transDate" id="transDate" class="textInput" value="<?=$transDatePost?>">
                </div>
            </div>

            <!-- 3rd Row: Type & Group -->
            <div class="transRow">
                <div>
                    <label for="transType">Type</label>
                    <select name="transType" id="transType" class="dropInput">
                        <option value="">[Select Type]</option>
                        <option value="inventory" <?php if($transTypePost == "inventory"):?>selected="selected"<?php endif;?>>1.  Inventory</option>
                        <option value="income" <?php if($transTypePost == "income"):?>selected="selected"<?php endif;?>>2. Income</option>
                        <option value="expenses" <?php if($transTypePost == "expenses"):?>selected="selected"<?php endif;?>>3. Expenses</option>
                        <option value="transfers" <?php if($transTypePost == "transfers"):?>selected="selected"<?php endif;?>>4.Transfers</option>
                    </select>
                </div>
                
                <div>
                    <label for="transGroup">Group</label>
                    <input type="text" name="transGroup" id="transGroup" class="dropInput" list="groupDrop" value="<?=$transGroupPost?>" autocomplete="off">
                        <datalist id="groupDrop">
                            <?php $groups = getGroups($_SESSION['clientID']);
                            foreach($groups as $group):?>
                            <?php echo('<script>"' . $group['transGroup'] . '"</script>')?>
                            <option value="<?= $group['transGroup'] ?>">
                            <?php endforeach;?>
                        </datalist>
                </div>
            </div>
            
            <!-- 5th Row:  Deposit + last 4-->
             <fieldset id="depField" disabled>
                <legend>Deposit</legend>
                <div class="transRow">
                        <input type="hidden" name="bankIn" id="bankIn" value="">
                    <div>
                        <label for="bankDepID">ID #</label>
                        <input type="number" name="bankDepID" id="bankDepID" class="textInput">
                    </div>
                    <div>
                        <!-- Make this a dropdown -->
                        <label for="bankDepName">Bank Name</label>
                        <input type="text" name="bankDepName" id="bankDepName" class="dropInput" value="<?=$transDepPost?>">
                    </div>
                    <div>
                        <label for="bankDepNum">Last 4</label>
                        <input type="text" name="bankDepNum" id="bankDepNum" class="textInput" maxlength="4">
                    </div>
                </div>
             </fieldset>
            
            
            <!-- 6th Row: Withdraw + last 4 -->
            <fieldset id="witField" disabled>
                <legend>Withdraw</legend>
                <div class="transRow">
                    <input type="hidden" name="bankOut" id="bankOut" value="">
                    <div>
                        <label for="bankWitID">ID #</label>
                        <input type="number" name="bankWitID" id="bankWitID" class="textInput">
                    </div>    
                    <div>
                        <!-- Make this a dropdown -->
                        <label for="bankWitName">Bank Name</label>
                        <input type="text" name="bankWitName" id="bankWitName" class="dropInput" value="<?=$transWitPost?>">
                    </div>
                    <div>
                        <label for="bankWitNum">Last 4</label>
                        <input type="number" name="bankWitNum" id="bankWitNum" class="textInput" maxlength="4">
                    </div>
                </div>                
            </fieldset>


            <!-- 7th Row: Check Num -->
            <div class="transRow">
                <div>
                    <label for="checkNum">Check Number</label>
                    <input type="text" name="checkNum" id="checkNum" class="textInput" max="8" value="<?=$transCheckPost?>">
                </div>
            </div>

            <div class="transRow">
                <div>
                    <label for="memo">Memo</label>
                    <textarea name="memo" id="memo" rows="7" cols="50" maxlength="250" form="transForm" method="POST" type="text"><?=$transMemoPost?></textarea>
                </div>
            </div>

            <div class="transRow">
                <div>
                    <input type="hidden" name="transID" id="transID" value="-1">
                </div>
                <div>
                    <input type="hidden" name="clientID" id="clientID" value="-1">
                </div>
            </div>

            <div class="transButtRow" >
                    <button type="submit" name="newTrans" id="newTrans" class="transButt accept" value="send">Save as New</button>
                    <button type="submit" name="editTrans" id="editTrans" class="transButt accept" value="edit">Update Transaction</button>

                    <button type="submit" name="delTrans" id="delTrans" class="transButt deny" value="delete">Delete</button>
                    <button type="submit" name="clearTrans" id="clearTrans" class="transButt deny" value="clear">Clear Form</button>

            </div>
            <!-- <div class="transButtRow"> -->
                   
            <!-- </div> -->
        </fieldset>
        </form>



</div>

<script type="text/javascript" src='functions\transactions.js'></script>