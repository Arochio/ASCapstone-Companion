    <?php 
        if(isset($_GET["clientID"])) {
            $_SESSION['clientID'] = $_GET["clientID"]; //save to session to avoid loss on post
        }
    ?>
    <header class="flex" style="align-items:flex-start;" id="mainHeader">

        <!--***Make this change based on selected client***-->
        <div class="flex" id="leftHead">
            <?php if(isset($_SESSION['clientID'])):
                $headClient = getOneClient($_SESSION['clientID']);
                $headName = $headClient[0]['clientFName'].' '.$headClient[0]['clientLName'];
                $_SESSION['clientName'] = $headName;
                $headNum = $headClient[0]['caseNum'];
            ?>
            <p id="clientHead">
                <?=$headName?>
            </p>
            <p id="numHead">#<?=$headNum?></p>
            <?php endif;?>
        </div>

        <div class="dropdown">
            <!-- ***Make this change based on logged in user -->
            <button class="dropbtn"><?=$_SESSION["displayName"]?></button>
            <div class="userMenu">

                <a href="settings.php">
                    <?php
                    if($_SESSION["isAdmin"]):?>
                        Admin/Settings
                    <?php
                    else:?>
                        User Settings
                    <?php endif;?>
                </a>

                <!-- Dark Mode toggle Put on Ice for now :( -->
                <!-- <div class="flex">
                    Dark Mode
                    <label class="toggle">
                        <input type="checkbox" id="isDarkMode">
                        <span class="slider"></span>
                    </label>
                </div> -->
                <a href="index.php">Log Out</a>
            </div>
        </div>
    </header>