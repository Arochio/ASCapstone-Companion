<div id="ledger">
    <div id="divContainer">
        <div class="header noPrint" id="ledgerHead">
            <a href="#" id="ledgerPop" style="visibility:hidden;"><i class="fa-solid fa-arrow-up-right-from-square "></i></a>
            <h3>Ledger</h3>
            <a href="" onclick="window.print();"><i class="fa-solid fa-print"></i></a>
        </div>

        <!-- This is the search options -->
        <div class="flex noPrint" id="ledgerSearch">
            <form class="flex">
                <div class="noPrint">
                    <label for="startDate">Start Date</label>
                    <input type="date" name="startDate" id="startDate" onchange="updateLedger();">
                </div>

                <div class="noPrint">
                    <label for="endDate">End Date</label>
                    <input type="date" name="endDate" id="endDate" onchange="updateLedger();">
                </div>
                <div class="noPrint">
                    <label for="bankSelect">Bank Name:</label>
                    <select name="bankSelect" id="bankSelect" class="dropInput">
                        <option value="-1">[Select Bank]</option>
                        <?php if(isset($_SESSION['clientID'])):
                                $_SESSION['clientBanks'] = getBanks($_SESSION['clientID']);
                                foreach($_SESSION['clientBanks'] as $banks) : ?>
                                    <?php if(isset($_GET['currentBank'])): ?>
                                        <option value="<?=$banks["bankID"]?>" id="bank<?=$banks["bankID"]?>"<?php if($_GET['currentBank'] == $banks['bankID']) {echo('selected="selected"');}?>><?=$banks["clientBankID"]?>. <?=$banks["bankName"]?> - <?=$banks["bankNum"]?></option>
                                    <?php else: ?>
                                        <option value="<?=$banks["bankID"]?>" id="bank<?=$banks["bankID"]?>"><?=$banks["clientBankID"]?>. <?=$banks["bankName"]?> - <?=$banks["bankNum"]?></option>
                                    <?php endif; ?>
                                <?php endforeach;?>
                        <?php endif;?>
                    </select>
                </div>
            </form>

        </div>

        <!-- Print Only Section -->
        <div class="printOnly" id="printHeader">

            <!-- Put a bank # key at top -->
            <div id="printBanks">
                <h2>Banks:</h2>
                <?php if(isset($_SESSION['clientID'])):
                    foreach($_SESSION['clientBanks'] as $banks) : ?>
                            <p><?=$banks["bankNum"]?> - <?=$banks["bankName"]?></p>
                    <?php endforeach;?>
                <?php endif;?>
            </div>
            <h2><?=$_SESSION['clientName']?></h2>

        </div><!-- End Print Only Section -->
        
        <hr>
        <div id="ledgerPadding">
            <div id = "ledgerMain" class="scroll">
                <table id="ledgerTable printable">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Transaction Name</th>
                            <th>Group</th>
                            <th>Amount</th>
                            <th>Type</th>
                            <th>Bank In</th>
                            <th>Bank Out</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if(isset($_SESSION['clientID'])) :
                            if(isset($_GET['currentBank'])) {
                                $transactions = getTrans($_SESSION['clientID'], $_GET['currentBank']);
                            }
                            else {
                                $transactions = getTrans($_SESSION['clientID'], FALSE); //FALSE for 2nd argument returns all transactions for client
                            }
                            if($transactions != "No Transactions Found"):
                                foreach($transactions as $trans) : 
                                    $transJSON = json_encode($trans);?>
                                    <tr id="<?= $trans['transID']?>" class="tr">
                                        <td><?=$trans['transDate']?></td>
                                        <td><?=$trans['transName']?></td>
                                        <td><?=$trans['transGroup']?></td>
                                        <td class="mono"><?='$' . number_format($trans['amount'], 2);?></td>
                                        <td><?=$trans['transType']?></td>
                                        <?php
                                            if($trans['bankIn'] == '') {$bankInClientID = '';} else {$bankInClientID = getBankFromID($trans['bankIn'])['bankNum'];}
                                            if($trans['bankOut'] == '') {$bankOutClientID = '';} else {$bankOutClientID = getBankFromID($trans['bankOut'])['bankNum'];}
                                        ?>
                                        <td><?=$bankInClientID?></td>
                                        <td><?=$bankOutClientID?></td>
                                        <td style="display: none;"><?= $transJSON ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else:?>
                                <tr class="justify-content: center;">
                                    <td colspan="7" style="text-align: center;">No Transactions Found</td>
                                </tr>
                            <?php endif;?>
                        <?php else: ?>
                            <td id="selectClient" colspan="7">Please Select A Client</td>
                        <?php 
                        endif;?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>